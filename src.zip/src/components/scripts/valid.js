import axios from "axios"

export default {
    data() {
        return {
            IIN: null,
            serialNumber: null,
            diplomNumber: null,
            data: null,

        }
    },
    methods: {
         async checkDiploma() {
            console.log('Fetching')
            const backHost = import.meta.env.VITE_SERVER_BACKEND_HOST;
            const backPort = import.meta.env.VITE_SERVER_BACKEND_PORT;
             await axios.get(`http://${backHost}:${backPort}/search?iin=${this.IIN}&serialNumber=${this.serialNumber}&number=${this.diplomNumber}`).then((response) => {
                this.data = response.data[0];
                console.log(this.data.fullname);
                // if(this.data.fullname ==undefined)
                // this.data = null;

                
            }).catch((error) => {
                console.log(error);
            });

        
        },

    },
}